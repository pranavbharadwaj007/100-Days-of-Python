file_one = open("file1.txt", "r").readlines()
file_two = open("file2.txt", "r").readlines()

result = [int(item) for item in file_one if item in file_two]

# Write your code above 👆

print(result)


